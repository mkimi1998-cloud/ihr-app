// Timber-industry palette: deep forest, heartwood amber, bone white.
export const C = {
  forest: '#0F3D2E', forestSoft: '#1D5A44', amber: '#C8841A', bone: '#F4F6F3',
  card: '#FFFFFF', ink: '#1B2A24', mute: '#5E7068', line: '#D5DDD8',
  ok: '#2E7D4F', bad: '#B3261E', badBg: '#FBE9E7',
};
