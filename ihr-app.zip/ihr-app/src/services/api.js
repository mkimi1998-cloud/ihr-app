import Constants from 'expo-constants';

const extra = Constants.expoConfig?.extra ?? {};
export const BASE_URL = extra.apiBaseUrl;
export const USE_MOCK = extra.useMock !== false;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

// Replace each TODO path with the real iHR endpoint and payload.
// The compiled APK does not expose them, so none are guessed here.
async function call(path, body) {
  const res = await fetch(BASE_URL + path, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error('Sila cuba sekali lagi');
  return res.json();
}

export async function registerUser({ name, staffNo, deviceId, photoUri }) {
  if (USE_MOCK) { await wait(900); return { name, staffNo, deviceId, photoUri }; }
  return call('TODO_REGISTER_PATH', { name, staffNo, deviceId });
}
export async function submitReport({ staffNo, kind, coords, photoUri, qr }) {
  if (USE_MOCK) { await wait(900); return { id: String(Date.now()), kind, at: new Date().toISOString(), coords, qr }; }
  return call('TODO_REPORT_PATH', { staffNo, kind, coords, qr });
}
export async function getHistory({ staffNo, from, to }) {
  if (USE_MOCK) {
    await wait(500);
    return Array.from({ length: 8 }, (_, i) => {
      const d = new Date(Date.now() - i * 864e5);
      return { id: String(i), kind: i % 3 === 0 ? 'QR' : 'GEO', at: d.toISOString(), status: i === 2 ? 'LEWAT' : 'BERJAYA' };
    }).filter((r) => new Date(r.at) >= from && new Date(r.at) <= new Date(to.getTime() + 864e5));
  }
  return call('TODO_HISTORY_PATH', { staffNo, from, to });
}
