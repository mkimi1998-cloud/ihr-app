export const C = {
  primary: '#B5452B', primaryDark: '#8E3320', primarySoft: '#F6E3DD',
  brown: '#5A3A22', bg: '#F7F3EF', card: '#FFFFFF', border: '#E5DAD2',
  text: '#2B1D14', muted: '#7A6A5F', success: '#2E7D4F', successBg: '#DFF1E6',
  warn: '#B7791F', warnBg: '#FBEBCB', danger: '#B3261E', dangerBg: '#F9DEDC',
};
export const R = { sm: 10, md: 14, lg: 20 };
export const shadow = { shadowColor: '#3b2314', shadowOpacity: 0.08, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 3 };
