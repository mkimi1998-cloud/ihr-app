import React from 'react';
import { View, Text, TextInput, Pressable, Image, Modal, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, R, shadow } from '../theme';

export const Card = ({ style, children }) => <View style={[s.card, shadow, style]}>{children}</View>;

export function Button({ title, onPress, icon, variant = 'solid', loading, disabled, style }) {
  const solid = variant === 'solid';
  return (
    <Pressable onPress={onPress} disabled={disabled || loading}
      style={({ pressed }) => [s.btn, solid ? s.btnSolid : s.btnOutline, (pressed || disabled) && { opacity: 0.75 }, style]}>
      {loading ? <ActivityIndicator color={solid ? '#fff' : C.primary} /> : (
        <>
          {icon && <Ionicons name={icon} size={20} color={solid ? '#fff' : C.primary} />}
          <Text style={[s.btnTxt, { color: solid ? '#fff' : C.primary }]}>{title}</Text>
        </>
      )}
    </Pressable>
  );
}

export function Field({ label, icon, error, ...props }) {
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={s.label}>{label}</Text>
      <View style={[s.input, error && { borderColor: C.danger }]}>
        {icon && <Ionicons name={icon} size={20} color={C.muted} />}
        <TextInput placeholderTextColor="#A89A90" style={s.inputTxt} {...props} />
      </View>
      {!!error && <Text style={s.err}>{error}</Text>}
    </View>
  );
}

export function Badge({ text, tone = 'success' }) {
  const m = { success: [C.successBg, C.success], warn: [C.warnBg, C.warn], danger: [C.dangerBg, C.danger] }[tone];
  return <View style={[s.badge, { backgroundColor: m[0] }]}><Text style={{ color: m[1], fontSize: 11, fontWeight: '700' }}>{text}</Text></View>;
}

export const Header = ({ title, sub }) => (
  <View style={s.header}>
    <Text style={s.hTitle}>{title}</Text>
    {!!sub && <Text style={s.hSub}>{sub}</Text>}
  </View>
);

const GIFS = {
  success: require('../../assets/images/success.gif'), danger: require('../../assets/images/danger.gif'),
  warning: require('../../assets/images/warning.gif'), loading: require('../../assets/images/loading.gif'),
};
export function StatusModal({ visible, type = 'success', title, message, onClose }) {
  return (
    <Modal transparent animationType="fade" visible={visible} onRequestClose={onClose}>
      <View style={s.backdrop}>
        <View style={[s.modal, shadow]}>
          <Image source={GIFS[type]} style={{ width: 96, height: 96 }} />
          <Text style={s.mTitle}>{title}</Text>
          {!!message && <Text style={s.mMsg}>{message}</Text>}
          {type !== 'loading' && <Button title="Tutup" onPress={onClose} style={{ alignSelf: 'stretch', marginTop: 16 }} />}
        </View>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  card: { backgroundColor: C.card, borderRadius: R.lg, padding: 16, borderWidth: 1, borderColor: C.border },
  btn: { height: 52, borderRadius: R.md, flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center' },
  btnSolid: { backgroundColor: C.primary }, btnOutline: { backgroundColor: '#fff', borderWidth: 1.5, borderColor: C.primary },
  btnTxt: { fontSize: 16, fontWeight: '700' },
  label: { fontSize: 12, fontWeight: '700', color: C.brown, marginBottom: 6 },
  input: { height: 50, borderRadius: R.md, borderWidth: 1, borderColor: C.border, backgroundColor: '#fff', paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 10 },
  inputTxt: { flex: 1, fontSize: 15, color: C.text }, err: { color: C.danger, fontSize: 12, marginTop: 4 },
  badge: { paddingHorizontal: 9, paddingVertical: 3, borderRadius: 99 },
  header: { backgroundColor: C.primary, paddingHorizontal: 20, paddingTop: 20, paddingBottom: 56 },
  hTitle: { color: '#fff', fontSize: 22, fontWeight: '800' }, hSub: { color: '#fff', opacity: 0.85, marginTop: 4 },
  backdrop: { flex: 1, backgroundColor: 'rgba(30,15,8,.55)', alignItems: 'center', justifyContent: 'center', padding: 28 },
  modal: { backgroundColor: '#fff', borderRadius: R.lg, padding: 24, alignItems: 'center', alignSelf: 'stretch' },
  mTitle: { fontSize: 18, fontWeight: '800', color: C.text, marginTop: 8, textAlign: 'center' },
  mMsg: { fontSize: 14, color: C.muted, marginTop: 6, textAlign: 'center' },
});
