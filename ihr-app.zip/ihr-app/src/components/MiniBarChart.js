import React from 'react';
import { View, Text } from 'react-native';
import { C } from '../theme';

// Simple 7-day attendance bar chart, no external chart library needed.
export default function MiniBarChart({ data }) {
  // data: [{ label: 'Isn', hours: 8.5, ontime: true }, ...]
  const max = Math.max(...data.map((d) => d.hours), 9);
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, height: 110, marginTop: 8 }}>
      {data.map((d, i) => (
        <View key={i} style={{ flex: 1, alignItems: 'center' }}>
          <Text style={{ fontSize: 10, color: C.muted, marginBottom: 4 }}>{d.hours ? d.hours.toFixed(1) : '-'}</Text>
          <View style={{ width: '70%', height: Math.max(6, (d.hours / max) * 70), borderRadius: 6,
            backgroundColor: d.hours === 0 ? C.border : d.ontime ? C.primary : C.warn }} />
          <Text style={{ fontSize: 11, color: C.muted, marginTop: 6, fontWeight: '600' }}>{d.label}</Text>
        </View>
      ))}
    </View>
  );
}
