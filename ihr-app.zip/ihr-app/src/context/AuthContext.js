import React, { createContext, useContext, useEffect, useState } from 'react';
import * as SecureStore from 'expo-secure-store';
const Ctx = createContext(null);
const KEY = 'ihr_user';
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    SecureStore.getItemAsync(KEY).then((v) => { if (v) setUser(JSON.parse(v)); }).finally(() => setReady(true));
  }, []);
  const save = async (u) => { setUser(u); await SecureStore.setItemAsync(KEY, JSON.stringify(u)); };
  const clear = async () => { setUser(null); await SecureStore.deleteItemAsync(KEY); };
  return <Ctx.Provider value={{ user, ready, save, clear }}>{children}</Ctx.Provider>;
}
