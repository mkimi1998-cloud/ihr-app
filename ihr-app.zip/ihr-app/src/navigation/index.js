import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { ActivityIndicator, View } from 'react-native';
import { useAuth } from '../context/AuthContext';
import RegisterScreen from '../screens/RegisterScreen';
import HomeScreen from '../screens/HomeScreen';
import HistoryScreen from '../screens/HistoryScreen';
import ProfileScreen from '../screens/ProfileScreen';
import ScanQRScreen from '../screens/ScanQRScreen';
import GeoTaggingScreen from '../screens/GeoTaggingScreen';
import { C } from '../theme';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const icons = { Utama: 'home', Sejarah: 'time', Profil: 'person' };

function Tabs() {
  return (
    <Tab.Navigator screenOptions={({ route }) => ({
      headerShown: false, tabBarActiveTintColor: C.primary, tabBarInactiveTintColor: C.muted,
      tabBarStyle: { height: 64, paddingBottom: 8, paddingTop: 6, borderTopColor: C.border },
      tabBarLabelStyle: { fontSize: 11, fontWeight: '700' },
      tabBarIcon: ({ color, size }) => <Ionicons name={icons[route.name]} size={size} color={color} />,
    })}>
      <Tab.Screen name="Utama" component={HomeScreen} />
      <Tab.Screen name="Sejarah" component={HistoryScreen} />
      <Tab.Screen name="Profil" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

export default function Navigation() {
  const { user, ready } = useAuth();
  if (!ready) return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={C.primary} /></View>;
  const hdr = { headerStyle: { backgroundColor: C.primary }, headerTintColor: '#fff', headerTitleStyle: { fontWeight: '800' } };
  return (
    <NavigationContainer>
      <Stack.Navigator>
        {user ? (
          <>
            <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
            <Stack.Screen name="ScanQR" component={ScanQRScreen} options={{ ...hdr, title: 'Imbas QR' }} />
            <Stack.Screen name="GeoTagging" component={GeoTaggingScreen} options={{ ...hdr, title: 'Daftar Geo Tagging' }} />
          </>
        ) : (
          <Stack.Screen name="Daftar" component={RegisterScreen} options={{ headerShown: false }} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
