import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { useAuth } from '../context/AuthContext';
import { submitReport } from '../services/api';
import { Button, StatusModal } from '../components/ui';
import { C } from '../theme';

export default function ScanQRScreen({ navigation }) {
  const { user } = useAuth();
  const [perm, ask] = useCameraPermissions();
  const [busy, setBusy] = useState(false);
  const [modal, setModal] = useState(null);

  if (!perm) return <View style={{ flex: 1, backgroundColor: C.bg }} />;
  if (!perm.granted) return (
    <View style={{ flex: 1, backgroundColor: C.bg, padding: 24, justifyContent: 'center', gap: 14 }}>
      <Text style={{ textAlign: 'center', color: C.text, fontSize: 16 }}>Kebenaran kamera diperlukan untuk mengimbas kod QR.</Text>
      <Button title="Benarkan Kamera" icon="camera-outline" onPress={ask} />
    </View>
  );

  const onScan = async ({ data }) => {
    if (busy) return;
    setBusy(true); setModal({ type: 'loading', title: 'Menghantar...' });
    try {
      await submitReport({ staffNo: user.staffNo, kind: 'QR', qr: data });
      setModal({ type: 'success', title: 'Berjaya lapor diri', message: 'Kehadiran anda telah direkodkan.' });
    } catch (e) { setModal({ type: 'danger', title: 'Gagal', message: e.message }); }
  };
  const close = () => { const ok = modal?.type === 'success'; setModal(null); setBusy(false); if (ok) navigation.goBack(); };

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <CameraView style={StyleSheet.absoluteFill} facing="back" barcodeScannerSettings={{ barcodeTypes: ['qr'] }} onBarcodeScanned={busy ? undefined : onScan} />
      <View style={s.overlay} pointerEvents="none">
        <View style={s.frame}>{['tl', 'tr', 'bl', 'br'].map((k) => <View key={k} style={[s.corner, s[k]]} />)}</View>
        <Text style={s.hint}>Imbas QR</Text>
        <Text style={s.hint2}>Halakan kamera ke kod QR di pejabat</Text>
      </View>
      <StatusModal visible={!!modal} {...modal} onClose={close} />
    </View>
  );
}
const s = StyleSheet.create({
  overlay: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  frame: { width: 250, height: 250 }, corner: { position: 'absolute', width: 44, height: 44, borderColor: '#fff' },
  tl: { top: 0, left: 0, borderTopWidth: 5, borderLeftWidth: 5, borderTopLeftRadius: 16 },
  tr: { top: 0, right: 0, borderTopWidth: 5, borderRightWidth: 5, borderTopRightRadius: 16 },
  bl: { bottom: 0, left: 0, borderBottomWidth: 5, borderLeftWidth: 5, borderBottomLeftRadius: 16 },
  br: { bottom: 0, right: 0, borderBottomWidth: 5, borderRightWidth: 5, borderBottomRightRadius: 16 },
  hint: { color: '#fff', fontSize: 20, fontWeight: '800', marginTop: 28 }, hint2: { color: '#fff', opacity: 0.8, marginTop: 4 },
});
