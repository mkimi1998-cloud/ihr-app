import React, { useState } from 'react';
import { View, Text, Image, ScrollView, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Application from 'expo-application';
import { useAuth } from '../context/AuthContext';
import { Button, Card, StatusModal } from '../components/ui';
import { updateDeviceId } from '../services/api';
import { C } from '../theme';

const Row = ({ icon, label, value }) => (
  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: C.border }}>
    <View style={{ width: 34, height: 34, borderRadius: 10, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
      <Ionicons name={icon} size={17} color={C.primary} />
    </View>
    <View style={{ flex: 1 }}>
      <Text style={{ fontSize: 11, color: C.muted }}>{label}</Text>
      <Text style={{ fontWeight: '700', color: C.text, marginTop: 1 }}>{value}</Text>
    </View>
  </View>
);

const MenuItem = ({ icon, label, onPress, danger }) => (
  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: C.border }}>
    <Ionicons name={icon} size={20} color={danger ? C.danger : C.text} />
    <Text style={{ flex: 1, fontSize: 14, fontWeight: '600', color: danger ? C.danger : C.text }}>{label}</Text>
    <Ionicons name="chevron-forward" size={18} color={C.muted} />
  </View>
);

export default function ProfileScreen() {
  const { user, update, clear } = useAuth();
  const [busy, setBusy] = useState(false);
  const [modal, setModal] = useState(null);

  const reset = () => Alert.alert('Padam pendaftaran?', 'Anda perlu mendaftar semula untuk menggunakan aplikasi.', [
    { text: 'Batal', style: 'cancel' }, { text: 'Padam', style: 'destructive', onPress: clear },
  ]);

  // Re-reads the phone's own device ID and, if it differs from the one on file
  // (new phone, factory reset, etc.), asks the server to re-link this staff number
  // to it. It never accepts a typed-in ID - only the real one the OS reports.
  const refreshDevice = () => {
    const current = Application.getAndroidId();
    if (current === user.deviceId) {
      return setModal({ type: 'success', title: 'ID Peranti terkini', message: 'Peranti ini sudah didaftarkan.' });
    }
    Alert.alert(
      'Kemaskini ID Peranti?',
      `ID Peranti lama: ${user.deviceId}\nID Peranti baharu: ${current}\n\nIni akan menghantar ID peranti baharu untuk disahkan.`,
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Kemaskini', onPress: async () => {
            setBusy(true); setModal({ type: 'loading', title: 'Mengemaskini...' });
            try {
              await updateDeviceId({ staffNo: user.staffNo, deviceId: current });
              await update({ deviceId: current });
              setModal({ type: 'success', title: 'ID Peranti dikemaskini' });
            } catch (e) {
              setModal({ type: 'danger', title: 'Gagal mengemaskini', message: e.message });
            } finally { setBusy(false); }
          },
        },
      ],
    );
  };
  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ paddingBottom: 30 }}>
      <View style={{ backgroundColor: C.primary, alignItems: 'center', paddingTop: 44, paddingBottom: 84 }}>
        <Image source={user.photoUri ? { uri: user.photoUri } : require('../../assets/avatar.png')} style={{ width: 96, height: 96, borderRadius: 48, borderWidth: 3, borderColor: '#fff', backgroundColor: '#fff' }} />
        <Text style={{ color: '#fff', fontSize: 20, fontWeight: '800', marginTop: 10 }}>{user.name}</Text>
        <Text style={{ color: '#fff', opacity: 0.85 }}>{user.staffNo}</Text>
        <View style={{ flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: 99, paddingHorizontal: 12, paddingVertical: 5, marginTop: 8, gap: 6, alignItems: 'center' }}>
          <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: '#8FE3A8' }} />
          <Text style={{ color: '#fff', fontSize: 11, fontWeight: '700' }}>Akaun aktif</Text>
        </View>
      </View>

      <View style={{ paddingHorizontal: 20, marginTop: -52, gap: 16 }}>
        <Card style={{ paddingVertical: 4 }}>
          <Text style={{ fontWeight: '800', fontSize: 13, color: C.brown, marginTop: 10, marginBottom: 2 }}>Maklumat Peribadi</Text>
          <Row icon="person-outline" label="Nama" value={user.name} />
          <Row icon="card-outline" label="Nombor Staf" value={user.staffNo} />
          <Row icon="business-outline" label="Jabatan" value="-" />
          <Row icon="briefcase-outline" label="Jawatan" value="-" />
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12 }}>
            <View style={{ width: 34, height: 34, borderRadius: 10, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="phone-portrait-outline" size={17} color={C.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 11, color: C.muted }}>ID Peranti</Text>
              <Text style={{ fontWeight: '700', color: C.text, marginTop: 1 }} numberOfLines={1}>{user.deviceId ?? '-'}</Text>
            </View>
            <Button title="Kemaskini" variant="outline" onPress={refreshDevice} loading={busy}
              style={{ height: 36, paddingHorizontal: 12 }} />
          </View>
        </Card>

        <Card style={{ paddingVertical: 0, paddingHorizontal: 16 }}>
          <Text style={{ fontWeight: '800', fontSize: 13, color: C.brown, marginTop: 14, marginBottom: 2 }}>Tetapan</Text>
          <MenuItem icon="notifications-outline" label="Notifikasi" />
          <MenuItem icon="lock-closed-outline" label="Privasi & Keselamatan" />
          <MenuItem icon="language-outline" label="Bahasa · Bahasa Melayu" />
          <MenuItem icon="help-circle-outline" label="Bantuan & Sokongan" />
        </Card>

        <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <Ionicons name="help-buoy-outline" size={26} color={C.primary} />
          <Text style={{ flex: 1, color: C.text, fontSize: 13 }}>Sila hubungi Bahagian Sumber Manusia untuk bantuan</Text>
        </Card>

        <Button title="Padam Pendaftaran" icon="trash-outline" variant="outline" onPress={reset} />
        <Text style={{ textAlign: 'center', color: C.muted, fontSize: 12 }}>iHR versi 5.0.0</Text>
      </View>
      <StatusModal visible={!!modal} {...modal} onClose={() => setModal(null)} />
    </ScrollView>
  );
}
