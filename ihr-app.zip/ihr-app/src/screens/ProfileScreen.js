import React from 'react';
import { View, Text, Image, ScrollView, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { Button, Card } from '../components/ui';
import { C } from '../theme';

const Row = ({ icon, label, value }) => (
  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: C.border }}>
    <Ionicons name={icon} size={20} color={C.primary} />
    <View style={{ flex: 1 }}><Text style={{ fontSize: 11, color: C.muted }}>{label}</Text><Text style={{ fontWeight: '700', color: C.text }}>{value}</Text></View>
  </View>
);

export default function ProfileScreen() {
  const { user, clear } = useAuth();
  const reset = () => Alert.alert('Padam pendaftaran?', 'Anda perlu mendaftar semula untuk menggunakan aplikasi.', [
    { text: 'Batal', style: 'cancel' }, { text: 'Padam', style: 'destructive', onPress: clear },
  ]);
  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ paddingBottom: 30 }}>
      <View style={{ backgroundColor: C.primary, alignItems: 'center', paddingTop: 44, paddingBottom: 84 }}>
        <Image source={user.photoUri ? { uri: user.photoUri } : require('../../assets/avatar.png')} style={{ width: 96, height: 96, borderRadius: 48, borderWidth: 3, borderColor: '#fff', backgroundColor: '#fff' }} />
        <Text style={{ color: '#fff', fontSize: 20, fontWeight: '800', marginTop: 10 }}>{user.name}</Text>
        <Text style={{ color: '#fff', opacity: 0.85 }}>{user.staffNo}</Text>
      </View>
      <View style={{ paddingHorizontal: 20, marginTop: -52, gap: 16 }}>
        <Card style={{ paddingVertical: 4 }}>
          <Row icon="person-outline" label="Nama" value={user.name} />
          <Row icon="card-outline" label="Nombor Staf" value={user.staffNo} />
          <Row icon="phone-portrait-outline" label="ID Peranti" value={user.deviceId ?? '-'} />
        </Card>
        <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <Ionicons name="help-buoy-outline" size={26} color={C.primary} />
          <Text style={{ flex: 1, color: C.text }}>Sila hubungi Bahagian Sumber Manusia untuk bantuan</Text>
        </Card>
        <Button title="Padam Pendaftaran" icon="trash-outline" variant="outline" onPress={reset} />
        <Text style={{ textAlign: 'center', color: C.muted, fontSize: 12 }}>iHR versi 1.1.0</Text>
      </View>
    </ScrollView>
  );
}
