import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, Image, ScrollView, Pressable } from 'react-native';
import * as Location from 'expo-location';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { submitReport } from '../services/api';
import { Button, Card, Badge, StatusModal } from '../components/ui';
import { C } from '../theme';

export default function GeoTaggingScreen({ navigation }) {
  const { user } = useAuth();
  const [coords, setCoords] = useState(null);
  const [locErr, setLocErr] = useState(null);
  const [photo, setPhoto] = useState(null);
  const [modal, setModal] = useState(null);
  const [busy, setBusy] = useState(false);

  const locate = useCallback(async () => {
    setLocErr(null); setCoords(null);
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') return setLocErr('Kebenaran lokasi diperlukan');
    try { setCoords((await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High })).coords); }
    catch { setLocErr('Gagal mendapatkan lokasi'); }
  }, []);
  useEffect(() => { locate(); }, [locate]);

  const snap = async () => {
    const r = await ImagePicker.launchCameraAsync({ quality: 0.6 });
    if (!r.canceled) setPhoto(r.assets[0].uri);
  };
  const send = async () => {
    if (!coords) return setModal({ type: 'warning', title: 'Lokasi belum diperoleh' });
    if (!photo) return setModal({ type: 'warning', title: 'Sila muat naik gambar' });
    setBusy(true); setModal({ type: 'loading', title: 'Menghantar...' });
    try {
      await submitReport({ staffNo: user.staffNo, kind: 'GEO', coords: { lat: coords.latitude, lng: coords.longitude }, photoUri: photo });
      setModal({ type: 'success', title: 'Berjaya lapor diri', message: 'Kehadiran anda telah direkodkan.' });
    } catch (e) { setModal({ type: 'danger', title: 'Gagal', message: e.message }); }
    finally { setBusy(false); }
  };
  const close = () => { const ok = modal?.type === 'success'; setModal(null); if (ok) navigation.goBack(); };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ padding: 20, gap: 16 }}>
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Text style={{ fontWeight: '800', fontSize: 16, color: C.text }}>Lokasi semasa</Text>
          <Badge text={coords ? 'DITEMUI' : locErr ? 'GAGAL' : 'MENCARI...'} tone={coords ? 'success' : locErr ? 'danger' : 'warn'} />
        </View>
        <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
          {[['Latitud', coords?.latitude], ['Longitud', coords?.longitude]].map(([l, v]) => (
            <View key={l} style={{ flex: 1, backgroundColor: C.bg, borderRadius: 12, padding: 12 }}>
              <Text style={{ fontSize: 11, color: C.muted }}>{l}</Text>
              <Text style={{ fontSize: 16, fontWeight: '700', color: C.text }}>{v != null ? v.toFixed(6) : '--'}</Text>
            </View>
          ))}
        </View>
        {coords && <Text style={{ color: C.muted, fontSize: 12, marginTop: 10 }}>Ketepatan ± {Math.round(coords.accuracy ?? 0)} m</Text>}
        {!!locErr && <Text style={{ color: C.danger, marginTop: 10 }}>{locErr}</Text>}
        <Button title="Muat semula lokasi" icon="refresh" variant="outline" onPress={locate} style={{ marginTop: 14 }} />
      </Card>
      <Card>
        <Text style={{ fontWeight: '800', fontSize: 16, color: C.text, marginBottom: 12 }}>Gambar</Text>
        <Pressable onPress={snap} style={{ height: 180, borderRadius: 14, borderWidth: 1.5, borderStyle: 'dashed', borderColor: C.border, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', backgroundColor: C.bg }}>
          {photo ? <Image source={{ uri: photo }} style={{ width: '100%', height: '100%' }} /> : (
            <><Ionicons name="camera-outline" size={34} color={C.muted} /><Text style={{ color: C.muted, marginTop: 6 }}>Ketik untuk ambil gambar</Text></>
          )}
        </Pressable>
      </Card>
      <Button title="Hantar Laporan" icon="paper-plane-outline" onPress={send} loading={busy} />
      <StatusModal visible={!!modal} {...modal} onClose={close} />
    </ScrollView>
  );
}
