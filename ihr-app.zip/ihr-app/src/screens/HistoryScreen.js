import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, Pressable, ActivityIndicator } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { getHistory } from '../services/api';
import { Card, Header, Badge } from '../components/ui';
import { C } from '../theme';

const fmt = (d) => d.toLocaleDateString('ms-MY', { day: '2-digit', month: 'short', year: 'numeric' });

export default function HistoryScreen() {
  const { user } = useAuth();
  const [from, setFrom] = useState(new Date(Date.now() - 7 * 864e5));
  const [to, setTo] = useState(new Date());
  const [picker, setPicker] = useState(null);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try { setRows(await getHistory({ staffNo: user.staffNo, from, to })); } finally { setLoading(false); }
  }, [user, from, to]);
  useEffect(() => { load(); }, [load]);

  const DateBox = ({ label, value, which }) => (
    <Pressable onPress={() => setPicker(which)} style={{ flex: 1 }}>
      <Text style={{ fontSize: 11, fontWeight: '700', color: C.brown, marginBottom: 4 }}>{label}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1, borderColor: C.border, borderRadius: 12, padding: 12, backgroundColor: '#fff' }}>
        <Ionicons name="calendar-outline" size={18} color={C.primary} /><Text style={{ fontWeight: '600', color: C.text }}>{fmt(value)}</Text>
      </View>
    </Pressable>
  );

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <Header title="Sejarah Laporan" sub="Rekod lapor diri anda" />
      <Card style={{ marginHorizontal: 20, marginTop: -36, flexDirection: 'row', gap: 12 }}>
        <DateBox label="Tarikh Mula" value={from} which="from" />
        <DateBox label="Tarikh Akhir" value={to} which="to" />
      </Card>
      {picker && (
        <DateTimePicker value={picker === 'from' ? from : to} mode="date" maximumDate={new Date()}
          onChange={(e, d) => { setPicker(null); if (e.type === 'set' && d) (picker === 'from' ? setFrom : setTo)(d); }} />
      )}
      {loading ? <ActivityIndicator style={{ marginTop: 40 }} color={C.primary} /> : (
        <FlatList data={rows} keyExtractor={(r) => r.id} contentContainerStyle={{ padding: 20, gap: 10 }}
          ListEmptyComponent={<Text style={{ textAlign: 'center', color: C.muted, marginTop: 30 }}>Tiada rekod dalam tempoh ini</Text>}
          renderItem={({ item }) => (
            <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 }}>
              <View style={{ width: 42, height: 42, borderRadius: 12, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name={item.kind === 'QR' ? 'qr-code' : 'location'} size={20} color={C.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontWeight: '700', color: C.text }}>{fmt(new Date(item.at))}</Text>
                <Text style={{ color: C.muted, fontSize: 12 }}>{new Date(item.at).toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit' })} · {item.kind === 'QR' ? 'Imbas QR' : 'Geo Tagging'}</Text>
              </View>
              <Badge text={item.status} tone={item.status === 'LEWAT' ? 'warn' : 'success'} />
            </Card>
          )} />
      )}
    </View>
  );
}
