import React, { useState } from 'react';
import { View, Text, Image, Pressable, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Application from 'expo-application';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { registerUser } from '../services/api';
import { Button, Card, Field, StatusModal } from '../components/ui';
import { C } from '../theme';

export default function RegisterScreen() {
  const { save } = useAuth();
  const [name, setName] = useState('');
  const [staffNo, setStaffNo] = useState('');
  const [photo, setPhoto] = useState(null);
  const [busy, setBusy] = useState(false);
  const [modal, setModal] = useState(null);
  const [errs, setErrs] = useState({});

  const pick = async () => {
    const r = await ImagePicker.launchCameraAsync({ quality: 0.6, cameraType: ImagePicker.CameraType.front });
    if (!r.canceled) setPhoto(r.assets[0].uri);
  };
  const submit = async () => {
    const e = {};
    if (!name.trim()) e.name = 'Sila masukkan nama';
    if (!/^[A-Za-z0-9-]{3,}$/.test(staffNo.trim())) e.staffNo = 'Sila masukkan nombor staff yang sah';
    setErrs(e);
    if (Object.keys(e).length) return setModal({ type: 'warning', title: 'Sila pastikan semua ruangan telah diisi' });
    if (!photo) return setModal({ type: 'warning', title: 'Sila muat naik gambar' });
    setBusy(true);
    try {
      const deviceId = Application.getAndroidId();
      await save(await registerUser({ name: name.trim(), staffNo: staffNo.trim(), deviceId, photoUri: photo }));
    } catch (err) {
      setModal({ type: 'danger', title: 'Pendaftaran gagal', message: err.message });
    } finally { setBusy(false); }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
        <View style={{ backgroundColor: C.primary, alignItems: 'center', paddingTop: 56, paddingBottom: 90, borderBottomLeftRadius: 32, borderBottomRightRadius: 32 }}>
          <Image source={require('../../assets/logo.jpg')} style={{ width: 84, height: 84, borderRadius: 18, backgroundColor: '#fff' }} />
          <Text style={{ color: '#fff', fontSize: 24, fontWeight: '800', marginTop: 12 }}>Daftar Pengguna Baru</Text>
          <Text style={{ color: '#fff', opacity: 0.85, marginTop: 4 }}>Aplikasi iHR · MTIB</Text>
        </View>
        <View style={{ paddingHorizontal: 20, marginTop: -56 }}>
          <Card>
            <Pressable onPress={pick} style={{ alignSelf: 'center', marginBottom: 18 }}>
              <Image source={photo ? { uri: photo } : require('../../assets/avatar.png')} style={{ width: 96, height: 96, borderRadius: 48, borderWidth: 3, borderColor: C.primarySoft }} />
              <View style={{ position: 'absolute', right: -2, bottom: -2, backgroundColor: C.primary, width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name="camera" size={16} color="#fff" />
              </View>
            </Pressable>
            <Field label="Nama" icon="person-outline" value={name} onChangeText={setName} placeholder="Nama penuh" error={errs.name} />
            <Field label="Nombor Staf" icon="card-outline" value={staffNo} onChangeText={setStaffNo} autoCapitalize="characters" placeholder="Nombor staf" error={errs.staffNo} />
            <Button title="Daftar" icon="checkmark-circle-outline" onPress={submit} loading={busy} style={{ marginTop: 6 }} />
          </Card>
          <Text style={{ textAlign: 'center', color: C.muted, fontSize: 12, marginTop: 18 }}>Sila hubungi Bahagian Sumber Manusia untuk bantuan</Text>
        </View>
      </ScrollView>
      <StatusModal visible={!!modal} {...modal} onClose={() => setModal(null)} />
    </KeyboardAvoidingView>
  );
}
