import React, { useEffect, useState } from 'react';
import { View, Text, Image, ScrollView, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { Button, Card, Badge } from '../components/ui';
import MiniBarChart from '../components/MiniBarChart';
import { getHistory } from '../services/api';
import { C } from '../theme';

const Action = ({ icon, label, onPress }) => (
  <Pressable onPress={onPress} style={{ flex: 1, alignItems: 'center', gap: 8 }}>
    <View style={{ width: 56, height: 56, borderRadius: 18, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
      <Ionicons name={icon} size={26} color={C.primary} />
    </View>
    <Text style={{ fontSize: 12, fontWeight: '700', color: C.text }}>{label}</Text>
  </Pressable>
);

const Stat = ({ value, label, tone = C.text }) => (
  <View style={{ flex: 1, alignItems: 'center', paddingVertical: 10 }}>
    <Text style={{ fontSize: 20, fontWeight: '800', color: tone }}>{value}</Text>
    <Text style={{ fontSize: 11, color: C.muted, marginTop: 2 }}>{label}</Text>
  </View>
);

const DAYS = ['Isn', 'Sel', 'Rab', 'Kha', 'Jum', 'Sab', 'Ahd'];

export default function HomeScreen({ navigation }) {
  const { user } = useAuth();
  const [last, setLast] = useState(null);
  const [week, setWeek] = useState([]);
  const [stats, setStats] = useState({ ontime: 0, late: 0, missed: 0 });

  useEffect(() => {
    const unsub = navigation.addListener('focus', async () => {
      const to = new Date(); const from = new Date(Date.now() - 6 * 864e5);
      try {
        const rows = await getHistory({ staffNo: user.staffNo, from, to });
        setLast(rows[0] ?? null);

        const byDay = {};
        rows.forEach((r) => { byDay[new Date(r.at).toDateString()] = r; });
        const chart = Array.from({ length: 7 }, (_, i) => {
          const d = new Date(Date.now() - (6 - i) * 864e5);
          const r = byDay[d.toDateString()];
          return { label: DAYS[(d.getDay() + 6) % 7], hours: r ? 7.5 + (r.status === 'LEWAT' ? -1 : Math.random() * 1.5) : 0, ontime: r?.status !== 'LEWAT' };
        });
        setWeek(chart);
        setStats({
          ontime: rows.filter((r) => r.status !== 'LEWAT').length,
          late: rows.filter((r) => r.status === 'LEWAT').length,
          missed: Math.max(0, 7 - rows.length),
        });
      } catch {}
    });
    return unsub;
  }, [navigation, user]);

  const now = new Date();
  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ paddingBottom: 30 }}>
      <View style={{ backgroundColor: C.primary, paddingTop: 40, paddingHorizontal: 20, paddingBottom: 90, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Image source={user.photoUri ? { uri: user.photoUri } : require('../../assets/avatar.png')} style={{ width: 50, height: 50, borderRadius: 25, backgroundColor: '#fff' }} />
        <View style={{ flex: 1 }}>
          <Text style={{ color: '#fff', opacity: 0.85, fontSize: 12 }}>Selamat datang</Text>
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '800' }} numberOfLines={1}>{user.name}</Text>
          <Text style={{ color: '#fff', opacity: 0.75, fontSize: 11, marginTop: 1 }}>Staf No. {user.staffNo}</Text>
        </View>
        <Pressable style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="notifications-outline" size={20} color="#fff" />
        </Pressable>
      </View>

      <View style={{ paddingHorizontal: 20, marginTop: -64, gap: 16 }}>
        <Card>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <View>
              <Text style={{ color: C.muted, fontSize: 12 }}>{now.toLocaleDateString('ms-MY', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</Text>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, marginTop: 2 }}>Sila lapor diri anda!</Text>
            </View>
            <Ionicons name="finger-print-outline" size={30} color={C.primary} />
          </View>
          <Text style={{ color: C.muted, marginTop: 8, marginBottom: 14, fontSize: 13 }}>Lapor diri menggunakan lokasi atau imbasan kod QR di pejabat.</Text>
          <Button title="Lapor Diri" icon="location" onPress={() => navigation.navigate('GeoTagging')} />
        </Card>

        <View style={{ flexDirection: 'row' }}>
          <Action icon="qr-code-outline" label="Imbas QR" onPress={() => navigation.navigate('ScanQR')} />
          <Action icon="location-outline" label="Geo Tagging" onPress={() => navigation.navigate('GeoTagging')} />
          <Action icon="time-outline" label="Sejarah" onPress={() => navigation.navigate('Sejarah')} />
          <Action icon="person-outline" label="Profil" onPress={() => navigation.navigate('Profil')} />
        </View>

        <Card>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={{ fontWeight: '800', fontSize: 15, color: C.text }}>Ringkasan 7 hari</Text>
            <Badge text={`${stats.ontime} TEPAT`} tone="success" />
          </View>
          <MiniBarChart data={week} />
          <View style={{ flexDirection: 'row', borderTopWidth: 1, borderTopColor: C.border, marginTop: 10 }}>
            <Stat value={stats.ontime} label="Tepat masa" tone={C.success} />
            <Stat value={stats.late} label="Lewat" tone={C.warn} />
            <Stat value={stats.missed} label="Tiada rekod" tone={C.danger} />
          </View>
        </Card>

        <Text style={{ fontSize: 15, fontWeight: '800', color: C.text }}>Laporan terkini</Text>
        <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name={last?.kind === 'QR' ? 'qr-code' : 'location'} size={22} color={C.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '700', color: C.text }}>{last ? new Date(last.at).toLocaleString('ms-MY') : 'Tiada laporan'}</Text>
            <Text style={{ color: C.muted, fontSize: 12 }}>{last ? (last.kind === 'QR' ? 'Imbas QR' : 'Geo Tagging') : 'Belum ada rekod dalam 7 hari'}</Text>
          </View>
          {last && <Badge text={last.status} tone={last.status === 'LEWAT' ? 'warn' : 'success'} />}
        </Card>

        <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center', backgroundColor: C.primarySoft, borderColor: C.primarySoft }}>
          <Ionicons name="information-circle-outline" size={22} color={C.primary} />
          <Text style={{ flex: 1, fontSize: 12, color: C.brown }}>Waktu pejabat: 8:00 pagi - 5:00 petang. Pastikan GPS dihidupkan sebelum melapor diri.</Text>
        </Card>
      </View>
    </ScrollView>
  );
}
