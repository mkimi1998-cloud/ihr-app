import React, { useEffect, useState } from 'react';
import { View, Text, Image, ScrollView, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { Button, Card, Header, Badge } from '../components/ui';
import { getHistory } from '../services/api';
import { C } from '../theme';

const Action = ({ icon, label, onPress }) => (
  <Pressable onPress={onPress} style={{ flex: 1, alignItems: 'center', gap: 8 }}>
    <View style={{ width: 56, height: 56, borderRadius: 18, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
      <Ionicons name={icon} size={26} color={C.primary} />
    </View>
    <Text style={{ fontSize: 12, fontWeight: '700', color: C.text }}>{label}</Text>
  </Pressable>
);

export default function HomeScreen({ navigation }) {
  const { user } = useAuth();
  const [last, setLast] = useState(null);
  useEffect(() => {
    const unsub = navigation.addListener('focus', async () => {
      const to = new Date(); const from = new Date(Date.now() - 7 * 864e5);
      try { setLast((await getHistory({ staffNo: user.staffNo, from, to }))[0] ?? null); } catch {}
    });
    return unsub;
  }, [navigation, user]);

  const now = new Date();
  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ paddingBottom: 30 }}>
      <View style={{ backgroundColor: C.primary, paddingTop: 40, paddingHorizontal: 20, paddingBottom: 90, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Image source={user.photoUri ? { uri: user.photoUri } : require('../../assets/avatar.png')} style={{ width: 50, height: 50, borderRadius: 25, backgroundColor: '#fff' }} />
        <View style={{ flex: 1 }}>
          <Text style={{ color: '#fff', opacity: 0.85, fontSize: 12 }}>Selamat datang</Text>
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '800' }} numberOfLines={1}>{user.name}</Text>
        </View>
        <Image source={require('../../assets/logo.jpg')} style={{ width: 40, height: 40, borderRadius: 10 }} />
      </View>
      <View style={{ paddingHorizontal: 20, marginTop: -64, gap: 16 }}>
        <Card>
          <Text style={{ color: C.muted, fontSize: 12 }}>{now.toLocaleDateString('ms-MY', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</Text>
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.text, marginVertical: 6 }}>Sila lapor diri anda!</Text>
          <Text style={{ color: C.muted, marginBottom: 14 }}>Lapor diri menggunakan lokasi atau imbasan kod QR di pejabat.</Text>
          <Button title="Lapor Diri" icon="location" onPress={() => navigation.navigate('GeoTagging')} />
        </Card>
        <View style={{ flexDirection: 'row' }}>
          <Action icon="qr-code-outline" label="Imbas QR" onPress={() => navigation.navigate('ScanQR')} />
          <Action icon="location-outline" label="Geo Tagging" onPress={() => navigation.navigate('GeoTagging')} />
          <Action icon="time-outline" label="Sejarah" onPress={() => navigation.navigate('Sejarah')} />
        </View>
        <Text style={{ fontSize: 15, fontWeight: '800', color: C.text }}>Laporan terkini</Text>
        <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Ionicons name={last?.kind === 'QR' ? 'qr-code' : 'location'} size={24} color={C.primary} />
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '700', color: C.text }}>{last ? new Date(last.at).toLocaleString('ms-MY') : 'Tiada laporan'}</Text>
            <Text style={{ color: C.muted, fontSize: 12 }}>{last ? (last.kind === 'QR' ? 'Imbas QR' : 'Geo Tagging') : 'Belum ada rekod dalam 7 hari'}</Text>
          </View>
          {last && <Badge text={last.status} tone={last.status === 'LEWAT' ? 'warn' : 'success'} />}
        </Card>
      </View>
    </ScrollView>
  );
}
