# iHR (MTIB) – rebuilt Expo project

Rebuilt from `iHR.apk` (Expo SDK 51, React Native 0.74, Hermes). Original screens and Malay text were
recovered from the compiled bundle: Daftar Pengguna Baru, Imbas QR, Daftar Geo Tagging, Sejarah (Tarikh Mula /
Tarikh Akhir), and Profil. Logo, avatar, forest image and status GIFs come from the APK. The layout is a new, more detailed design in the MTIB rust-and-brown palette.

## Run
    npm install
    npx expo start            # scan with Expo Go on Android

## Build the .apk
    npm i -g eas-cli && eas login
    eas init                  # links this project to YOUR Expo account
    npm run build:apk         # eas build -p android --profile preview  -> downloads an .apk

## Connect the real server
`app.json > extra.useMock` is `true`, so the app runs on sample data. Set it to `false` and fill in the three
`TODO_*_PATH` calls in `src/services/api.js` with the real iHR endpoints. The compiled APK does not
expose them, so they are not guessed here.

## Notes
- Package id is `my.gov.mtib.ihr`. A build signed with your key cannot update over the original app; uninstall it first, or change the id in `app.json`.
- Original Sentry, push-notification and Expo-updates setup were left out because they use the original owner's accounts.

## Build the .apk with no setup (GitHub, browser only)
1. Create a free account at github.com, then New repository (private is fine).
2. Upload everything in this folder, including the hidden `.github` folder, via Add file > Upload files.
3. Open the Actions tab > "Build APK" > Run workflow. Wait about 10 to 20 minutes.
4. Open the finished run, scroll to Artifacts, download `iHR-apk`, unzip it, and install the .apk.
The APK is signed with a debug key, which is fine for installing and testing but not for the Play Store.
