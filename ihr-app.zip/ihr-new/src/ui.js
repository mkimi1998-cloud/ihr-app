import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, shadow } from './theme';
export const Card = ({ children, style }) => <View style={[s.card, shadow, style]}>{children}</View>;
export const H = ({ children, icon }) => (
  <View style={s.h}>{icon && <Ionicons name={icon} size={18} color={C.primary} />}<Text style={s.ht}>{children}</Text></View>);
export const Btn = ({ title, onPress, icon, loading, kind = 'primary', style }) => (
  <TouchableOpacity disabled={loading} onPress={onPress} activeOpacity={0.85}
    style={[s.btn, kind === 'ghost' && s.ghost, kind === 'danger' && { backgroundColor: C.bad }, style]}>
    {loading ? <ActivityIndicator color="#fff" /> : <>
      {icon && <Ionicons name={icon} size={18} color={kind === 'ghost' ? C.primary : '#fff'} />}
      <Text style={[s.bt, kind === 'ghost' && { color: C.primary }]}>{title}</Text></>}
  </TouchableOpacity>);
export const Row = ({ k, v }) => (<View style={s.row}><Text style={s.rk}>{k}</Text><Text style={s.rv}>{v}</Text></View>);
export const Stat = ({ icon, label, value, color = C.primary }) => (
  <View style={[s.stat, shadow]}><View style={[s.si, { backgroundColor: color + '1A' }]}><Ionicons name={icon} size={20} color={color} /></View>
    <Text style={s.sv}>{value ?? '-'}</Text><Text style={s.sl}>{label}</Text></View>);
const s = StyleSheet.create({
  card: { backgroundColor: C.card, borderRadius: 16, padding: 16, marginBottom: 14 },
  h: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  ht: { fontSize: 15, fontWeight: '700', color: C.text },
  btn: { backgroundColor: C.primary, borderRadius: 12, paddingVertical: 14, paddingHorizontal: 18, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },
  ghost: { backgroundColor: '#fff', borderWidth: 1.5, borderColor: C.primary },
  bt: { color: '#fff', fontWeight: '700', fontSize: 15 },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: C.line, gap: 12 },
  rk: { color: C.sub, fontSize: 13, flex: 1 }, rv: { color: C.text, fontSize: 13, fontWeight: '600', flex: 1.2, textAlign: 'right' },
  stat: { flex: 1, backgroundColor: C.card, borderRadius: 16, padding: 14, alignItems: 'flex-start' },
  si: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  sv: { fontSize: 20, fontWeight: '800', color: C.text }, sl: { fontSize: 12, color: C.sub, marginTop: 2 },
});
