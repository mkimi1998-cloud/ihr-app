export const C = { primary:'#0B5ED7', dark:'#083B8A', accent:'#14B8A6', bg:'#F3F6FB', card:'#FFFFFF',
  text:'#0F172A', sub:'#64748B', line:'#E2E8F0', ok:'#16A34A', warn:'#F59E0B', bad:'#DC2626' };
export const shadow = { shadowColor:'#0F172A', shadowOpacity:0.08, shadowRadius:10, shadowOffset:{width:0,height:4}, elevation:3 };
