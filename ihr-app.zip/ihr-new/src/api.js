import * as SecureStore from 'expo-secure-store';
// Same backend as the original iHR app. Nothing here changes the database schema.
export const BASE = 'https://ihr.mtib.gov.my/';
export const EP = {
  login: 'api/user_registration',
  dashboard: 'api/dashboard',
  geotag: 'api/geotagging',
  qr: 'api/qr_scanner',
  selfReport: 'api/mia_reporting',
  reason: 'api/reason',
  reference: 'api/reference',
  fcm: 'api/fcm_store_token',
};
// !! Field names below must match what the original app sent. Confirm against
// the backend/controller and edit ONLY this block if they differ. !!
export const FIELDS = { staff: 'staff_no', password: 'password' };

export async function post(path, body = {}) {
  const form = new FormData();
  Object.entries(body).forEach(([k, v]) => v != null && form.append(k, v));
  const res = await fetch(BASE + path, { method: 'POST', body: form, headers: { Accept: 'application/json' } });
  const txt = await res.text();
  try { return JSON.parse(txt); } catch { throw new Error('Respons pelayan tidak sah (' + res.status + ')'); }
}
export const session = {
  save: (u) => SecureStore.setItemAsync('ihr_user', JSON.stringify(u)),
  load: async () => { try { const s = await SecureStore.getItemAsync('ihr_user'); return s ? JSON.parse(s) : null; } catch { return null; } },
  clear: () => SecureStore.deleteItemAsync('ihr_user'),
};
export const label = (k) => String(k).replace(/_/g, ' ').replace(/\b\w/g, (m) => m.toUpperCase());
// Flatten any JSON into [key, value] rows so EVERY detail returned by the server is viewable.
export function rows(obj, prefix = '') {
  if (obj == null) return [];
  if (typeof obj !== 'object') return [[prefix || 'Nilai', String(obj)]];
  return Object.entries(obj).flatMap(([k, v]) =>
    v && typeof v === 'object' ? rows(v, prefix ? `${prefix} ${k}` : k) : [[prefix ? `${prefix} ${k}` : k, v == null || v === '' ? '-' : String(v)]]);
}
