import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, TextInput, ScrollView, StyleSheet, Alert, RefreshControl, Modal, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as Location from 'expo-location';
import { C, shadow } from './theme';
import { Card, H, Btn, Row, Stat } from './ui';
import { post, EP, FIELDS, rows, label, session } from './api';

const now = () => new Date();
const greet = () => { const h = now().getHours(); return h < 12 ? 'Selamat Pagi' : h < 15 ? 'Selamat Tengah Hari' : h < 19 ? 'Selamat Petang' : 'Selamat Malam'; };

/* ---------------- LOGIN ---------------- */
export function Login({ onDone }) {
  const [staff, setStaff] = useState(''); const [pw, setPw] = useState(''); const [show, setShow] = useState(false); const [busy, setBusy] = useState(false);
  const go = async () => {
    if (!staff) return Alert.alert('iHR', 'Sila masukkan nombor staf yang sah');
    setBusy(true);
    try {
      const r = await post(EP.login, { [FIELDS.staff]: staff.trim(), [FIELDS.password]: pw });
      const user = { staff: staff.trim(), data: r };
      await session.save(user); onDone(user);
    } catch (e) { Alert.alert('Ralat', e.message + '\nSila cuba sekali lagi'); } finally { setBusy(false); }
  };
  return (
    <LinearGradient colors={[C.dark, C.primary, '#3B82F6']} style={{ flex: 1, justifyContent: 'center', padding: 24 }}>
      <View style={{ alignItems: 'center', marginBottom: 28 }}>
        <View style={st.logo}><Ionicons name="people" size={40} color={C.primary} /></View>
        <Text style={{ color: '#fff', fontSize: 30, fontWeight: '800', marginTop: 12 }}>iHR</Text>
        <Text style={{ color: '#DBEAFE' }}>Sistem Sumber Manusia MTIB</Text>
      </View>
      <View style={[st.loginCard, shadow]}>
        <Text style={st.lbl}>Nombor Staf</Text>
        <View style={st.input}><Ionicons name="person-outline" size={18} color={C.sub} />
          <TextInput value={staff} onChangeText={setStaff} placeholder="Contoh: 12345" autoCapitalize="none" style={st.ti} /></View>
        <Text style={st.lbl}>Kata Laluan</Text>
        <View style={st.input}><Ionicons name="lock-closed-outline" size={18} color={C.sub} />
          <TextInput value={pw} onChangeText={setPw} secureTextEntry={!show} placeholder="••••••" style={st.ti} />
          <Ionicons name={show ? 'eye-off-outline' : 'eye-outline'} size={18} color={C.sub} onPress={() => setShow(!show)} /></View>
        <Btn title="Log Masuk" icon="log-in-outline" onPress={go} loading={busy} style={{ marginTop: 14 }} />
      </View>
      <Text style={{ color: '#BFDBFE', textAlign: 'center', marginTop: 18, fontSize: 12 }}>Versi 2.0.0 • Lembaga Perindustrian Kayu Malaysia</Text>
    </LinearGradient>);
}

/* ---------------- HOME ---------------- */
export function Home({ user, go }) {
  const [d, setD] = useState(null); const [ref, setRef] = useState(false); const [err, setErr] = useState('');
  const load = useCallback(async () => {
    setRef(true); setErr('');
    try { setD(await post(EP.dashboard, { [FIELDS.staff]: user.staff })); } catch (e) { setErr(e.message); } setRef(false);
  }, [user.staff]);
  useEffect(() => { load(); }, [load]);
  const flat = rows(d);
  const pick = (re) => { const f = flat.find(([k]) => re.test(k)); return f ? f[1] : '-'; };
  return (
    <ScrollView refreshControl={<RefreshControl refreshing={ref} onRefresh={load} />} contentContainerStyle={{ paddingBottom: 24 }}>
      <LinearGradient colors={[C.dark, C.primary]} style={st.hero}>
        <Text style={{ color: '#BFDBFE' }}>{greet()},</Text>
        <Text style={{ color: '#fff', fontSize: 22, fontWeight: '800' }}>{pick(/name|nama/i) !== '-' ? pick(/name|nama/i) : 'Staf ' + user.staff}</Text>
        <Text style={{ color: '#DBEAFE', marginTop: 4 }}>{now().toLocaleDateString('ms-MY', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</Text>
      </LinearGradient>
      <View style={{ padding: 16, marginTop: -30 }}>
        <View style={{ flexDirection: 'row', gap: 12, marginBottom: 14 }}>
          <Stat icon="log-in-outline" label="Masuk" value={pick(/in|masuk/i)} color={C.ok} />
          <Stat icon="log-out-outline" label="Keluar" value={pick(/out|keluar/i)} color={C.warn} />
        </View>
        <Card><H icon="flash-outline">Tindakan Pantas</H>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="Imbas QR" icon="qr-code-outline" onPress={() => go('attendance')} style={{ flex: 1 }} />
            <Btn title="Lapor Diri" icon="location-outline" kind="ghost" onPress={() => go('attendance')} style={{ flex: 1 }} />
          </View></Card>
        <Card><H icon="list-outline">Maklumat Lengkap</H>
          {err ? <Text style={{ color: C.bad }}>{err}</Text> : null}
          {flat.length === 0 && !err ? <Text style={{ color: C.sub }}>Tiada data. Tarik ke bawah untuk muat semula.</Text> : null}
          {flat.map(([k, v], i) => <Row key={i} k={label(k)} v={v} />)}</Card>
      </View>
    </ScrollView>);
}

/* ---------------- ATTENDANCE ---------------- */
export function Attendance({ user }) {
  const [perm, ask] = useCameraPermissions(); const [scan, setScan] = useState(false); const [busy, setBusy] = useState(false);
  const [reasons, setReasons] = useState([]); const [reason, setReason] = useState(''); const [note, setNote] = useState(''); const [last, setLast] = useState(null);
  useEffect(() => { post(EP.reason, {}).then((r) => setReasons(rows(r).map(([, v]) => v))).catch(() => {}); }, []);
  const coords = async () => {
    const p = await Location.requestForegroundPermissionsAsync();
    if (p.status !== 'granted') throw new Error('Tiada akses lokasi');
    const l = await Location.getCurrentPositionAsync({}); return l.coords;
  };
  const geotag = async () => {
    setBusy(true);
    try { const c = await coords();
      const r = await post(EP.geotag, { [FIELDS.staff]: user.staff, latitude: c.latitude, longitude: c.longitude });
      setLast(r); Alert.alert('Daftar Geo Tagging', 'Berjaya dihantar'); } catch (e) { Alert.alert('Ralat', e.message); } setBusy(false);
  };
  const onQR = async ({ data }) => {
    setScan(false); setBusy(true);
    try { const c = await coords().catch(() => ({}));
      const r = await post(EP.qr, { [FIELDS.staff]: user.staff, qr_code: data, latitude: c.latitude, longitude: c.longitude });
      setLast(r); Alert.alert('Imbas QR', 'Kehadiran direkodkan'); } catch (e) { Alert.alert('Ralat', e.message); } setBusy(false);
  };
  const self = async () => {
    if (!reason) return Alert.alert('iHR', 'Sila pastikan semua ruangan telah diisi');
    setBusy(true);
    try { const c = await coords();
      const r = await post(EP.selfReport, { [FIELDS.staff]: user.staff, reason, remark: note, latitude: c.latitude, longitude: c.longitude });
      setLast(r); Alert.alert('Lapor Diri', 'Berjaya dihantar'); } catch (e) { Alert.alert('Ralat', e.message); } setBusy(false);
  };
  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <Card><H icon="qr-code-outline">Imbas QR</H>
        <Text style={st.hint}>Imbas kod QR di lokasi pejabat untuk merekod kehadiran.</Text>
        <Btn title="Buka Kamera" icon="camera-outline" onPress={async () => { if (!perm?.granted) { const r = await ask(); if (!r.granted) return Alert.alert('Tiada akses kamera'); } setScan(true); }} loading={busy} /></Card>
      <Card><H icon="navigate-outline">Daftar Geo Tagging</H>
        <Text style={st.hint}>Rekod lokasi semasa anda (GPS).</Text>
        <Btn title="Hantar Lokasi" icon="locate-outline" kind="ghost" onPress={geotag} loading={busy} /></Card>
      <Card><H icon="document-text-outline">Lapor Diri / Kerja Luar</H>
        <Text style={st.lbl}>Sebab / Jenis Aktiviti</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 10 }}>
          {reasons.length === 0 ? <TextInput value={reason} onChangeText={setReason} placeholder="Taip sebab" style={[st.input, { flex: 1 }]} /> :
            reasons.map((r, i) => (<TouchableOpacity key={i} onPress={() => setReason(r)} style={[st.chip, reason === r && { backgroundColor: C.primary }]}>
              <Text style={{ color: reason === r ? '#fff' : C.text, fontSize: 12 }}>{r}</Text></TouchableOpacity>))}
        </View>
        <Text style={st.lbl}>Catatan</Text>
        <TextInput value={note} onChangeText={setNote} multiline placeholder="Catatan (pilihan)" style={[st.input, { height: 80, textAlignVertical: 'top' }]} />
        <Btn title="Hantar Laporan" icon="send-outline" onPress={self} loading={busy} style={{ marginTop: 12 }} /></Card>
      {last && <Card><H icon="checkmark-circle-outline">Respons Terakhir</H>{rows(last).map(([k, v], i) => <Row key={i} k={label(k)} v={v} />)}</Card>}
      <Modal visible={scan} animationType="slide" onRequestClose={() => setScan(false)}>
        <CameraView style={{ flex: 1 }} barcodeScannerSettings={{ barcodeTypes: ['qr'] }} onBarcodeScanned={onQR} />
        <Btn title="Tutup" kind="danger" onPress={() => setScan(false)} style={{ position: 'absolute', bottom: 40, left: 24, right: 24 }} />
      </Modal>
    </ScrollView>);
}

/* ---------------- PROFILE ---------------- */
export function Profile({ user, onLogout }) {
  const [d, setD] = useState(null);
  useEffect(() => { post(EP.reference, { [FIELDS.staff]: user.staff }).then(setD).catch(() => {}); }, [user.staff]);
  const mine = rows(user.data); const ref = rows(d);
  return (
    <ScrollView contentContainerStyle={{ paddingBottom: 24 }}>
      <LinearGradient colors={[C.dark, C.primary]} style={[st.hero, { alignItems: 'center' }]}>
        <View style={st.avatar}><Ionicons name="person" size={44} color={C.primary} /></View>
        <Text style={{ color: '#fff', fontSize: 20, fontWeight: '800', marginTop: 10 }}>Staf {user.staff}</Text>
      </LinearGradient>
      <View style={{ padding: 16, marginTop: -30 }}>
        <Card><H icon="id-card-outline">Maklumat Staf</H>{mine.length ? mine.map(([k, v], i) => <Row key={i} k={label(k)} v={v} />) : <Row k="Nombor Staf" v={user.staff} />}</Card>
        {ref.length > 0 && <Card><H icon="information-circle-outline">Rujukan</H>{ref.map(([k, v], i) => <Row key={i} k={label(k)} v={v} />)}</Card>}
        <Btn title="Log Keluar" icon="log-out-outline" kind="danger" onPress={onLogout} />
      </View>
    </ScrollView>);
}

const st = StyleSheet.create({
  logo: { width: 76, height: 76, borderRadius: 22, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  loginCard: { backgroundColor: '#fff', borderRadius: 20, padding: 20 },
  lbl: { fontSize: 12, color: C.sub, marginBottom: 6, marginTop: 8, fontWeight: '600' },
  input: { flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1, borderColor: C.line, borderRadius: 12, paddingHorizontal: 12, backgroundColor: '#F8FAFC' },
  ti: { flex: 1, paddingVertical: 12, color: C.text },
  hero: { paddingTop: 56, paddingBottom: 52, paddingHorizontal: 20 },
  hint: { color: C.sub, fontSize: 13, marginBottom: 12 },
  chip: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, backgroundColor: '#E8EEF9' },
  avatar: { width: 84, height: 84, borderRadius: 42, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
});
