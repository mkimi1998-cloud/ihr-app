import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { C } from './src/theme';
import { session } from './src/api';
import { Login, Home, Attendance, Profile } from './src/screens';

const TABS = [['home', 'Utama', 'home'], ['attendance', 'Kehadiran', 'finger-print'], ['profile', 'Profil', 'person']];
export default function App() {
  const [user, setUser] = useState(undefined); const [tab, setTab] = useState('home');
  useEffect(() => { session.load().then(setUser); }, []);
  if (user === undefined) return <View style={{ flex: 1, justifyContent: 'center' }}><ActivityIndicator size="large" color={C.primary} /></View>;
  if (!user) return (<><StatusBar style="light" /><Login onDone={setUser} /></>);
  const logout = async () => { await session.clear(); setUser(null); setTab('home'); };
  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar style="light" />
      <View style={{ flex: 1 }}>
        {tab === 'home' && <Home user={user} go={setTab} />}
        {tab === 'attendance' && <Attendance user={user} />}
        {tab === 'profile' && <Profile user={user} onLogout={logout} />}
      </View>
      <View style={{ flexDirection: 'row', backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: C.line, paddingBottom: 14, paddingTop: 8 }}>
        {TABS.map(([k, t, ic]) => (
          <TouchableOpacity key={k} onPress={() => setTab(k)} style={{ flex: 1, alignItems: 'center' }}>
            <Ionicons name={tab === k ? ic : ic + '-outline'} size={24} color={tab === k ? C.primary : C.sub} />
            <Text style={{ fontSize: 11, marginTop: 2, color: tab === k ? C.primary : C.sub, fontWeight: tab === k ? '700' : '500' }}>{t}</Text>
          </TouchableOpacity>))}
      </View>
    </View>);
}
